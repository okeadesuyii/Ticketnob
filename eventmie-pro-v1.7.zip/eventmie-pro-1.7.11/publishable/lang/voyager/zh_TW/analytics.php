<?php

return [
    'by_pageview'            => '以 PV',
    'by_sessions'            => '以 Session',
    'by_users'               => '以用戶',
    'no_client_id'           => '若需查看統計數據，您需要先註冊 Google Analytics 並將所提供的網站 Client ID 以金鑰名：<code>google_analytics_client_id</code> 添加到您的 Voyager 設置。在 Google Developer Console 上獲取您的金鑰信息：',
    'set_view'               => '選擇一個視圖',
    'this_vs_last_week'      => '本週 VS 上週',
    'this_vs_last_year'      => '今年 VS 去年',
    'top_browsers'           => '使用最多的瀏覽器',
    'top_countries'          => '訪問量最高的國家',
    'various_visualizations' => '復合圖表',
];
