<?php

return [
    'field_password_keep'          => '留空以保持不變',
    'field_select_dd_relationship' => '確保在 :class 類的 :method 方法中設置適當的關系。',
    'type_checkbox'                => '複選框',
    'type_codeeditor'              => '程式碼編輯器',
    'type_file'                    => '文件',
    'type_image'                   => '圖像',
    'type_radiobutton'             => '單選按鈕',
    'type_richtextbox'             => '富文本框',
    'type_selectdropdown'          => '選擇下拉',
    'type_textarea'                => '文本區域',
    'type_textbox'                 => '文本框',
];
