<?php

return [
    'avatar'           => '頭像',
    'edit'             => '更改個人資料',
    'edit_user'        => '編輯用戶',
    'password'         => '密碼',
    'password_hint'    => '留空為不修改密碼',
    'role'             => '角色',
    'roles'            => '角色',
    'role_default'     => '預設角色',
    'roles_additional' => '附加角色',
    'user_role'        => '用戶角色',
];
