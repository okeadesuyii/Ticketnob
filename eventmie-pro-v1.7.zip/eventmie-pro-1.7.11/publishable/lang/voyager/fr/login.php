<?php

return [
    'loggingin'    => 'Se connecter',
    'signin_below' => 'Connectez-vous ci-dessous :',
    'welcome'      => 'Bienvenue dans Voyager, le panneau d\'administration qui manquait à Laravel',
];
