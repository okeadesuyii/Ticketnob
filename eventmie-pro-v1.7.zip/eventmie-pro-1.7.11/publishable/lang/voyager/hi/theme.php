<?php

return [
    'footer_copyright'  => '<i class="voyager-heart"> </i> के साथ',
    'footer_copyright2' => 'रम से बना और भी रम',
];
