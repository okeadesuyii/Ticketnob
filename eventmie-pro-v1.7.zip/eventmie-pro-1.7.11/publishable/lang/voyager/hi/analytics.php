<?php

return [
    'by_pageview'            => 'पेजव्यू द्वारा',
    'by_sessions'            => 'बाइ सेशन',
    'by_users'               => 'उपयोगकर्ताओं द्वारा',
    'no_client_id'           => 'एनालिटिक्स देखने के लिए आपको एक Google एनालिटिक्स क्लाइंट आईडी प्राप्त करना होगा और इसे कुंजी <कोड> google_analytics_client_id </ code> के लिए अपनी सेटिंग्स में जोड़ना होगा। अपने Google डेवलपर कंसोल में अपनी कुंजी प्राप्त करें: ',
    'set_view'               => 'एक दृश्य चुनें',
    'this_vs_last_week'      => 'दिस वीक बनाम लास्ट वीक',
    'this_vs_last_year'      => 'इस साल बनाम पिछले साल',
    'top_browsers'           => 'टॉप ब्राउजर्स',
    'top_countries'          => 'शीर्ष देश',
    'various_visualizations' => 'विभिन्न दृश्य',
];
