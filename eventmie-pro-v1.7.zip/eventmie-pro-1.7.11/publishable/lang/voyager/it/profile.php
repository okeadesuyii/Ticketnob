<?php

return [
    'avatar'           => 'Avatar',
    'edit'             => 'Modifica il mio profilo',
    'edit_user'        => 'Modifica Utente',
    'password'         => 'Password',
    'password_hint'    => 'Lasciare vuoto per mantenere lo stesso',
    'role'             => 'Role',
    'roles'            => 'Ruolo',
    'role_default'     => 'Ruolo predefinito',
    'roles_additional' => 'Ruoli addizionali',
    'user_role'        => 'Ruolo Utente',
];
