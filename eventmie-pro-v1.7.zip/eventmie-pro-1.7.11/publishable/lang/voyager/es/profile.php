<?php

return [
    'avatar'            => 'Avatar',
    'edit'              => 'Editar mi perfil',
    'edit_user'         => 'Editar usuario',
    'password'          => 'Contraseña',
    'password_hint'     => 'Dejar vacío para mantener el mismo',
    'role'              => 'Rol',
    'role_default'      => 'Rol predeterminado',
    'roles'             => 'Roles',
    'roles_additional'  => 'Roles adicionales',
    'user_role'         => 'Rol del usuario',
];
