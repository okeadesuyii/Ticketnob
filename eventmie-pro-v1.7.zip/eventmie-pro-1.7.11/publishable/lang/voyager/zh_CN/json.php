<?php

return [
    'invalid'           => 'JSON 无效',
    'invalid_message'   => '看起来您引入的是一个无效的 JSON',
    'valid'             => 'JSON 有效',
    'validation_errors' => '验证错误',
];
