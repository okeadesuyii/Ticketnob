<?php

return [
    'last_week' => 'الأسبوع الماضي',
    'last_year' => 'السنة الماضية',
    'this_week' => 'هذا الأسبوع',
    'this_year' => 'هذا العام',
];
